# main.py — Football Dashboard
# Lance le menu principal du programme

from stats import get_classement, afficher_buteurs
from simulation import simuler_saison
from visualization import afficher_classement, afficher_simulation, comparer_equipes


def banniere():
    print("""
=================================
    FOOTBALL DASHBOARD 2025-26
    Stats + Simulation de saison
=================================
    """)


def choisir_championnat():
    # Demande quel championnat afficher
    print("Quel championnat veux-tu voir ?")
    print("  [1] Ligue 1")
    print("  [2] Premier League")
    print("  [3] La Liga")
    print("  [4] Bundesliga")
    print("  [5] Serie A")

    choix = input("\nTon choix (1-5) : ").strip()

    championnats = {
        "1": "ligue1",
        "2": "premier_league",
        "3": "la_liga",
        "4": "bundesliga",
        "5": "serie_a",
    }

    return championnats.get(choix, "ligue1")


def menu(championnat):
    noms = {
        "ligue1": "Ligue 1",
        "premier_league": "Premier League",
        "la_liga": "La Liga",
        "bundesliga": "Bundesliga",
        "serie_a": "Serie A",
    }
    print(f"\n--- {noms[championnat]} ---")
    print("  [1] Classement")
    print("  [2] Meilleurs buteurs")
    print("  [3] Simuler la fin de saison")
    print("  [4] Comparer deux equipes")
    print("  [0] Quitter")
    return input("\nTon choix : ").strip()


def run():
    banniere()
    championnat = choisir_championnat()

    while True:
        choix = menu(championnat)

        if choix == "1":
            print("\nRecuperation du classement...")
            classement = get_classement(championnat)
            afficher_classement(classement, championnat)

        elif choix == "2":
            afficher_buteurs(championnat)

        elif choix == "3":
            print("\nLancement de la simulation...")
            classement = get_classement(championnat)
            resultats = simuler_saison(classement)
            afficher_simulation(resultats, championnat)

        elif choix == "4":
            equipe1 = input("Nom de la 1ere equipe : ").strip()
            equipe2 = input("Nom de la 2eme equipe : ").strip()
            classement = get_classement(championnat)
            comparer_equipes(classement, equipe1, equipe2, championnat)

        elif choix == "0":
            print("\nA bientot !")
            break

        else:
            print("Choix invalide.")


if __name__ == "__main__":
    run()
