# visualization.py — Graphiques matplotlib pour le football dashboard

import matplotlib.pyplot as plt
import numpy as np

# Couleurs du dashboard
VERT   = "#00A650"
BLEU   = "#2979FF"
ROUGE  = "#FF4757"
JAUNE  = "#FFD32A"
FOND   = "#0e1318"
TEXTE  = "#e8eef5"
GRILLE = "#1f2d3d"

PALETTE = [VERT, BLEU, ROUGE, JAUNE, "#00bcd4", "#a29bfe", "#fd79a8", "#fdcb6e", "#74b9ff", "#55efc4"]


def creer_graphique(titre, taille=(12, 7)):
    # Cree une figure avec le style sombre du dashboard
    fig, ax = plt.subplots(figsize=taille)
    fig.patch.set_facecolor(FOND)
    ax.set_facecolor(FOND)
    ax.set_title(titre, fontsize=14, fontweight="bold", color=TEXTE, pad=16)
    ax.tick_params(colors=TEXTE)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(GRILLE)
    ax.spines["bottom"].set_color(GRILLE)
    ax.grid(color=GRILLE, linestyle="--", alpha=0.5)
    return fig, ax


def afficher_classement(classement, championnat):
    # Graphique barres horizontales — classement top 10
    top10 = classement[:10]
    noms   = [e["equipe"].split()[-1] for e in top10]  # Raccourcit les noms longs
    points = [e["points"] for e in top10]

    fig, ax = creer_graphique(f"Classement — {championnat.replace('_', ' ').title()}")

    barres = ax.barh(
        list(reversed(noms)),
        list(reversed(points)),
        color=PALETTE[:10],
        edgecolor=FOND,
        height=0.6,
    )

    # Affiche les points a l'interieur de chaque barre
    for barre, pts in zip(barres, reversed(points)):
        ax.text(
            barre.get_width() - 1,
            barre.get_y() + barre.get_height() / 2,
            str(pts),
            va="center", ha="right",
            color="white", fontweight="bold", fontsize=9,
        )

    ax.set_xlabel("Points", color=TEXTE)
    ax.tick_params(axis="y", colors=TEXTE)
    plt.tight_layout()

    nom_fichier = f"classement_{championnat}.png"
    plt.savefig(nom_fichier, dpi=150, bbox_inches="tight")
    print(f"Graphique sauvegarde : {nom_fichier}")
    plt.show()


def afficher_simulation(resultats, championnat):
    # Graphique barres horizontales — probabilites de titre
    # On garde seulement les equipes avec au moins 1% de chance
    filtres = [r for r in resultats if r["pct_titre"] >= 1.0] or resultats[:5]

    noms   = [r["equipe"].split()[-1] for r in filtres]
    titres = [r["pct_titre"] for r in filtres]
    top4   = [r["pct_top4"]  for r in filtres]

    fig, ax = creer_graphique(f"Simulation Monte Carlo — {championnat.replace('_', ' ').title()}", taille=(12, 6))

    x = np.arange(len(noms))
    largeur = 0.35

    ax.barh(x - largeur/2, titres, largeur, label="Titre %", color=VERT,  alpha=0.85)
    ax.barh(x + largeur/2, top4,   largeur, label="Top 4 %", color=BLEU, alpha=0.85)

    ax.set_yticks(x)
    ax.set_yticklabels(noms, color=TEXTE)
    ax.set_xlabel("Probabilite (%)", color=TEXTE)
    ax.legend(labelcolor=TEXTE, facecolor=FOND)

    plt.tight_layout()

    nom_fichier = f"simulation_{championnat}.png"
    plt.savefig(nom_fichier, dpi=150, bbox_inches="tight")
    print(f"Graphique sauvegarde : {nom_fichier}")
    plt.show()


def comparer_equipes(classement, nom1, nom2, championnat):
    # Compare deux equipes sur 5 criteres avec des barres groupees
    # Recherche insensible a la casse (ex: "psg" trouve "Paris Saint-Germain")
    def trouver(nom):
        nom = nom.lower()
        for e in classement:
            if nom in e["equipe"].lower():
                return e
        return None

    eq1 = trouver(nom1)
    eq2 = trouver(nom2)

    if not eq1:
        print(f"Equipe introuvable : '{nom1}'")
        print("Equipes disponibles :", [e["equipe"] for e in classement])
        return
    if not eq2:
        print(f"Equipe introuvable : '{nom2}'")
        print("Equipes disponibles :", [e["equipe"] for e in classement])
        return

    criteres = ["Points", "Victoires", "Nuls", "Buts pour", "Buts contre"]
    valeurs1 = [eq1["points"], eq1["victoires"], eq1["nuls"], eq1["buts_pour"], eq1["buts_contre"]]
    valeurs2 = [eq2["points"], eq2["victoires"], eq2["nuls"], eq2["buts_pour"], eq2["buts_contre"]]

    fig, ax = creer_graphique(f"{eq1['equipe']} vs {eq2['equipe']}")

    x = np.arange(len(criteres))
    largeur = 0.35

    barres1 = ax.bar(x - largeur/2, valeurs1, largeur, label=eq1["equipe"], color=VERT,  edgecolor=FOND)
    barres2 = ax.bar(x + largeur/2, valeurs2, largeur, label=eq2["equipe"], color=ROUGE, edgecolor=FOND)

    # Valeurs au-dessus des barres
    for b in list(barres1) + list(barres2):
        ax.text(
            b.get_x() + b.get_width() / 2,
            b.get_height() + 0.5,
            str(int(b.get_height())),
            ha="center", va="bottom",
            fontsize=9, color=TEXTE,
        )

    ax.set_xticks(x)
    ax.set_xticklabels(criteres, color=TEXTE)
    ax.legend(labelcolor=TEXTE, facecolor=FOND)

    plt.tight_layout()

    nom_fichier = f"comparaison_{nom1[:6]}_{nom2[:6]}.png"
    plt.savefig(nom_fichier, dpi=150, bbox_inches="tight")
    print(f"Graphique sauvegarde : {nom_fichier}")
    plt.show()
