# simulation.py — Simulation Monte Carlo de fin de saison football
#
# Comment ca marche :
# On lance N fois une simulation complete des matchs restants.
# Pour chaque match, on tire au hasard un gagnant en fonction
# de la force des deux equipes (points par match joue).
# A la fin, on compte combien de fois chaque equipe termine 1ere.

import random
from copy import deepcopy

NB_SIMULATIONS = 500


def force_equipe(equipe):
    # Calcule la "force" d'une equipe = points par match joue
    matchs = max(equipe.get("joues", 1), 1)
    return equipe.get("points", 1) / matchs


def probabilite_victoire(equipe_a, equipe_b):
    # Retourne la probabilite que A gagne contre B
    # Formule : force_A / (force_A + force_B)
    fa = force_equipe(equipe_a)
    fb = force_equipe(equipe_b)
    total = fa + fb
    if total == 0:
        return 0.5
    return fa / total


def jouer_un_match(equipe_a, equipe_b):
    # Simule un match et met a jour les stats des deux equipes
    proba_a = probabilite_victoire(equipe_a, equipe_b)
    tirage = random.random()

    if tirage < proba_a:
        # A gagne
        equipe_a["points"] += 3
        equipe_a["victoires"] += 1
        equipe_b["defaites"] += 1
    elif tirage < proba_a + 0.22:
        # Match nul (22% de chance environ)
        equipe_a["points"] += 1
        equipe_b["points"] += 1
        equipe_a["nuls"] += 1
        equipe_b["nuls"] += 1
    else:
        # B gagne
        equipe_b["points"] += 3
        equipe_b["victoires"] += 1
        equipe_a["defaites"] += 1

    equipe_a["joues"] += 1
    equipe_b["joues"] += 1


def simuler_une_fois(classement, nb_matchs):
    # Copie le classement pour ne pas modifier l'original
    copie = deepcopy(classement)
    n = len(copie)

    for _ in range(nb_matchs):
        # Tire deux equipes differentes au hasard
        i, j = random.sample(range(n), 2)
        jouer_un_match(copie[i], copie[j])

    # Trie par points puis difference de buts
    copie.sort(key=lambda x: (x["points"], x["buts_pour"] - x["buts_contre"]), reverse=True)
    return copie


def simuler_saison(classement):
    # Estime les matchs restants (saison = 34 ou 38 journees selon le champ.)
    nb_equipes = len(classement)
    journees_jouees = classement[0].get("joues", 28)

    # Bundesliga = 34 journees, autres = 38
    total_journees = 34 if nb_equipes == 18 else 38
    journees_restantes = total_journees - journees_jouees
    nb_matchs = max(0, int(journees_restantes * nb_equipes / 2))

    print(f"  {NB_SIMULATIONS} simulations, {nb_matchs} matchs restants estimes...")

    # Compteurs pour chaque equipe
    nb_titres = {e["equipe"]: 0 for e in classement}
    nb_top4   = {e["equipe"]: 0 for e in classement}
    nb_rel    = {e["equipe"]: 0 for e in classement}

    for i in range(NB_SIMULATIONS):
        if i % 100 == 0:
            print(f"  Simulation {i}/{NB_SIMULATIONS}...")

        resultat = simuler_une_fois(classement, nb_matchs)

        for pos, equipe in enumerate(resultat):
            nom = equipe["equipe"]
            if pos == 0:
                nb_titres[nom] += 1
            if pos < 4:
                nb_top4[nom] += 1
            if pos >= len(resultat) - 3:
                nb_rel[nom] += 1

    # Calcule les pourcentages et trie par proba de titre
    resultats = []
    for equipe in classement:
        nom = equipe["equipe"]
        resultats.append({
            "equipe":     nom,
            "pct_titre":  round(nb_titres[nom] / NB_SIMULATIONS * 100, 1),
            "pct_top4":   round(nb_top4[nom]   / NB_SIMULATIONS * 100, 1),
            "pct_rel":    round(nb_rel[nom]     / NB_SIMULATIONS * 100, 1),
        })

    resultats.sort(key=lambda x: x["pct_titre"], reverse=True)

    print("\nResultats de la simulation :")
    print(f"  {'Equipe':<30} {'Titre':>8} {'Top 4':>8} {'Rel.':>8}")
    print("  " + "-" * 56)
    for r in resultats:
        print(f"  {r['equipe']:<30} {r['pct_titre']:>7}% {r['pct_top4']:>7}% {r['pct_rel']:>7}%")

    return resultats
