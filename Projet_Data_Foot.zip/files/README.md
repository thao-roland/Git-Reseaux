# ⚽ Sport Dashboard — Stats & Simulation de saison

Dashboard Python interactif qui combine **analyse de données sportives réelles** et **simulation probabiliste de fin de saison**, pour les 5 Grands Championnats de Foot.

---

## Fonctionnalités

| Fonctionnalité | Description |
|---|---|
| 📊 Classement en temps réel | Récupère les données via API et les affiche en graphique |
| 🥇 Top scoreurs | Affiche les meilleurs joueurs/buteurs de la saison |
| 🎲 Simulation | Prédit les chances de titre de chaque équipe |
| ⚡ Comparaison d'équipes | Compare deux équipes sur plusieurs critères |

---

## Architecture du projet

```
sport_dashboard/
│
├── main.py            # Point d'entrée — menu interactif
├── stats.py           # Récupération des données via APIs externes
├── simulation.py      # Algorithme de simulation Monte Carlo
├── visualization.py   # Génération des graphiques (matplotlib)
└── requirements.txt   # Dépendances Python
```

### Rôle de chaque fichier

- **`main.py`** : orchestre l'ensemble, gère le menu utilisateur et appelle les bons modules selon le choix
- **`stats.py`** : communique avec les APIs sportives (balldontlie le football-data.org ), normalise les données dans un format standard
- **`simulation.py`** : implémente l'algorithme de Monte Carlo — simule 1000 fins de saison possibles pour calculer des probabilités de titre
- **`visualization.py`** : transforme les données en graphiques matplotlib clairs et exportables en PNG

---

## Installation

### Prérequis
- Python 3.10+
- pip

### Étapes

```bash
# 1. Cloner le dépôt
git clone https://github.com/VOTRE_USERNAME/sport-dashboard.git
cd sport-dashboard

# 2. (Optionnel) Créer un environnement virtuel
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# 3. Installer les dépendances
pip install -r requirements.txt

# 4. Lancer le programme
python main.py
```

### Configuration des APIs

Une clé API gratuite est nécessaire :
1. S'inscrire sur [football-data.org](https://www.football-data.org/client/register)
2. Récupérer la clé reçue par email
3. La renseigner dans `stats.py` à la ligne `FOOTBALL_API_KEY = "VOTRE_CLE_ICI"`

---

## Algorithme de simulation (Monte Carlo)

Le cœur du projet est une simulation de type **Monte Carlo** :

1. **État initial** : on part du classement réel actuel
2. **Matchs restants** : on estime le nombre de matchs qu'il reste à jouer
3. **Pour chaque match simulé** :
   - On tire deux équipes au hasard
   - On calcule la probabilité de victoire de chaque équipe selon sa "force" (win%, points/match ) avec la formule :
     ```
     P(A gagne) = force_A / (force_A + force_B)
     ```
   - On tire le résultat avec `random.random()` et on met à jour le classement
4. **On répète 1000 fois** pour obtenir une distribution statistique
5. **Résultat** : pour chaque équipe, on calcule le % de simulations où elle termine première

Cette approche permet d'obtenir non pas une prédiction déterministe, mais une **distribution de probabilités** qui reflète l'incertitude inhérente au sport.

---

## Exemples de sorties

### Simulation de saison
![Exemple simulation](simulation_foot.png)

---

## APIs utilisées

| API | Sport | Clé requise | Documentation |
|---|---|---|---|
| [football-data.org](https://www.football-data.org) | Ligue 1 | Oui (gratuite) | [Docs](https://www.football-data.org/documentation/quickstart) |

---

## Dépendances

```
requests    # Appels HTTP vers les APIs
matplotlib  # Génération des graphiques
numpy       # Calculs numériques (barres groupées)
```

---

## Auteur

Roland Thao
