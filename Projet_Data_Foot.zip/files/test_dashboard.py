# test_dashboard.py — Tests basiques du dashboard football
# Lancer avec : python test_dashboard.py

from stats import get_classement, DONNEES_SECOURS
from simulation import simuler_saison, probabilite_victoire, NB_SIMULATIONS
import simulation


def test_classement_non_vide():
    # Verifie que les donnees de secours existent pour chaque championnat
    championnats = ["ligue1", "premier_league", "la_liga", "bundesliga", "serie_a"]
    for champ in championnats:
        data = DONNEES_SECOURS.get(champ, [])
        assert len(data) > 0, f"Donnees vides pour {champ}"
        assert "equipe" in data[0], f"Cle 'equipe' manquante dans {champ}"
        assert "points" in data[0], f"Cle 'points' manquante dans {champ}"
    print("Test 1 OK — donnees de secours valides pour les 5 championnats")


def test_probabilite_victoire():
    # Une equipe forte doit avoir une proba plus haute qu'une equipe faible
    equipe_forte = {"joues": 10, "points": 25, "buts_pour": 20, "buts_contre": 5}
    equipe_faible = {"joues": 10, "points": 5, "buts_pour": 5, "buts_contre": 20}
    proba = probabilite_victoire(equipe_forte, equipe_faible)
    assert proba > 0.7, f"Proba trop faible : {proba}"
    print("Test 2 OK — probabilite de victoire coherente")


def test_simulation_ligue1():
    # Lance une simulation rapide sur la Ligue 1 et verifie les resultats
    simulation.NB_SIMULATIONS = 50  # Reduit pour aller vite

    classement = DONNEES_SECOURS["ligue1"]
    resultats = simuler_saison(classement)

    assert len(resultats) > 0, "Aucun resultat de simulation"
    total_titres = sum(r["pct_titre"] for r in resultats)
    assert 80 <= total_titres <= 120, f"Total titres anormal : {total_titres}"
    print("Test 3 OK — simulation Ligue 1 fonctionnelle")


def test_simulation_bundesliga():
    # Verifie que la Bundesliga (18 equipes, 34 journees) fonctionne aussi
    simulation.NB_SIMULATIONS = 50

    classement = DONNEES_SECOURS["bundesliga"]
    resultats = simuler_saison(classement)

    assert len(resultats) == 18, f"Nombre d'equipes anormal : {len(resultats)}"
    print("Test 4 OK — simulation Bundesliga fonctionnelle")


def test_get_classement_fallback():
    # Si la cle API est fausse, le fallback doit retourner les donnees de secours
    from stats import get_classement
    classement = get_classement("serie_a")
    assert len(classement) > 0, "get_classement a retourne une liste vide"
    print("Test 5 OK — fallback API fonctionne")


if __name__ == "__main__":
    print("Lancement des tests...\n")
    test_classement_non_vide()
    test_probabilite_victoire()
    test_simulation_ligue1()
    test_simulation_bundesliga()
    test_get_classement_fallback()
    print("\nTous les tests sont passes !")
