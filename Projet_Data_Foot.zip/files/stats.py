# stats.py — Recuperation des donnees football via API
# Source : football-data.org (cle gratuite sur football-data.org)

import requests

# Cle API a remplir apres inscription sur football-data.org
CLE_API = "VOTRE_CLE_ICI"

# URL de base de l'API
URL_API = "https://api.football-data.org/v4"

# IDs des championnats sur football-data.org
IDS_CHAMPIONNATS = {
    "ligue1":         2015,
    "premier_league": 2021,
    "la_liga":        2014,
    "bundesliga":     2002,
    "serie_a":        2019,
}

# Donnees de secours si l'API ne repond pas (Ligue 1 J.28 — avril 2026)
DONNEES_SECOURS = {
    "ligue1": [
        {"equipe": "Paris Saint-Germain", "joues": 27, "victoires": 20, "nuls": 3,  "defaites": 4,  "buts_pour": 61, "buts_contre": 23, "points": 63},
        {"equipe": "RC Lens",             "joues": 28, "victoires": 19, "nuls": 2,  "defaites": 7,  "buts_pour": 54, "buts_contre": 27, "points": 59},
        {"equipe": "LOSC Lille",          "joues": 28, "victoires": 15, "nuls": 5,  "defaites": 8,  "buts_pour": 45, "buts_contre": 34, "points": 50},
        {"equipe": "Olympique Marseille", "joues": 28, "victoires": 15, "nuls": 4,  "defaites": 9,  "buts_pour": 55, "buts_contre": 37, "points": 49},
        {"equipe": "AS Monaco",           "joues": 28, "victoires": 15, "nuls": 4,  "defaites": 9,  "buts_pour": 49, "buts_contre": 39, "points": 49},
        {"equipe": "Olympique Lyonnais",  "joues": 28, "victoires": 14, "nuls": 6,  "defaites": 8,  "buts_pour": 41, "buts_contre": 29, "points": 48},
        {"equipe": "Stade Rennais",       "joues": 28, "victoires": 13, "nuls": 8,  "defaites": 7,  "buts_pour": 47, "buts_contre": 40, "points": 47},
        {"equipe": "RC Strasbourg",       "joues": 28, "victoires": 12, "nuls": 7,  "defaites": 9,  "buts_pour": 46, "buts_contre": 34, "points": 43},
        {"equipe": "FC Lorient",          "joues": 28, "victoires": 9,  "nuls": 11, "defaites": 8,  "buts_pour": 38, "buts_contre": 42, "points": 38},
        {"equipe": "Toulouse FC",         "joues": 28, "victoires": 10, "nuls": 7,  "defaites": 11, "buts_pour": 39, "buts_contre": 35, "points": 37},
        {"equipe": "Stade Brestois",      "joues": 28, "victoires": 10, "nuls": 6,  "defaites": 12, "buts_pour": 37, "buts_contre": 43, "points": 36},
        {"equipe": "Angers SCO",          "joues": 28, "victoires": 9,  "nuls": 6,  "defaites": 13, "buts_pour": 24, "buts_contre": 37, "points": 33},
        {"equipe": "Paris FC",            "joues": 28, "victoires": 7,  "nuls": 11, "defaites": 10, "buts_pour": 33, "buts_contre": 44, "points": 32},
        {"equipe": "Le Havre AC",         "joues": 28, "victoires": 6,  "nuls": 10, "defaites": 12, "buts_pour": 23, "buts_contre": 36, "points": 28},
        {"equipe": "OGC Nice",            "joues": 28, "victoires": 7,  "nuls": 6,  "defaites": 15, "buts_pour": 33, "buts_contre": 55, "points": 27},
        {"equipe": "AJ Auxerre",          "joues": 28, "victoires": 5,  "nuls": 8,  "defaites": 15, "buts_pour": 23, "buts_contre": 37, "points": 23},
        {"equipe": "FC Nantes",           "joues": 27, "victoires": 4,  "nuls": 6,  "defaites": 17, "buts_pour": 24, "buts_contre": 45, "points": 18},
        {"equipe": "FC Metz",             "joues": 28, "victoires": 3,  "nuls": 6,  "defaites": 19, "buts_pour": 25, "buts_contre": 60, "points": 15},
    ],
    "premier_league": [
        {"equipe": "Arsenal",          "joues": 28, "victoires": 20, "nuls": 6,  "defaites": 2,  "buts_pour": 61, "buts_contre": 18, "points": 66},
        {"equipe": "Manchester City",  "joues": 26, "victoires": 20, "nuls": 4,  "defaites": 2,  "buts_pour": 75, "buts_contre": 22, "points": 64},
        {"equipe": "Liverpool",        "joues": 28, "victoires": 18, "nuls": 5,  "defaites": 5,  "buts_pour": 68, "buts_contre": 31, "points": 59},
        {"equipe": "Newcastle United", "joues": 28, "victoires": 16, "nuls": 6,  "defaites": 6,  "buts_pour": 52, "buts_contre": 32, "points": 54},
        {"equipe": "Aston Villa",      "joues": 28, "victoires": 15, "nuls": 5,  "defaites": 8,  "buts_pour": 58, "buts_contre": 41, "points": 50},
        {"equipe": "Chelsea",          "joues": 28, "victoires": 14, "nuls": 6,  "defaites": 8,  "buts_pour": 55, "buts_contre": 38, "points": 48},
        {"equipe": "Tottenham",        "joues": 28, "victoires": 13, "nuls": 5,  "defaites": 10, "buts_pour": 49, "buts_contre": 44, "points": 44},
        {"equipe": "Man. United",      "joues": 28, "victoires": 12, "nuls": 5,  "defaites": 11, "buts_pour": 42, "buts_contre": 46, "points": 41},
        {"equipe": "Brighton",         "joues": 28, "victoires": 11, "nuls": 8,  "defaites": 9,  "buts_pour": 48, "buts_contre": 43, "points": 41},
        {"equipe": "Nottm Forest",     "joues": 28, "victoires": 11, "nuls": 7,  "defaites": 10, "buts_pour": 37, "buts_contre": 36, "points": 40},
        {"equipe": "Brentford",        "joues": 28, "victoires": 11, "nuls": 6,  "defaites": 11, "buts_pour": 44, "buts_contre": 44, "points": 39},
        {"equipe": "Fulham",           "joues": 28, "victoires": 10, "nuls": 8,  "defaites": 10, "buts_pour": 38, "buts_contre": 40, "points": 38},
        {"equipe": "West Ham",         "joues": 28, "victoires": 9,  "nuls": 7,  "defaites": 12, "buts_pour": 36, "buts_contre": 48, "points": 34},
        {"equipe": "Everton",          "joues": 28, "victoires": 8,  "nuls": 8,  "defaites": 12, "buts_pour": 32, "buts_contre": 43, "points": 32},
        {"equipe": "Crystal Palace",   "joues": 28, "victoires": 8,  "nuls": 7,  "defaites": 13, "buts_pour": 30, "buts_contre": 45, "points": 31},
        {"equipe": "Leeds United",     "joues": 28, "victoires": 8,  "nuls": 6,  "defaites": 14, "buts_pour": 34, "buts_contre": 50, "points": 30},
        {"equipe": "Wolverhampton",    "joues": 28, "victoires": 7,  "nuls": 7,  "defaites": 14, "buts_pour": 29, "buts_contre": 51, "points": 28},
        {"equipe": "Sunderland",       "joues": 28, "victoires": 7,  "nuls": 5,  "defaites": 16, "buts_pour": 28, "buts_contre": 54, "points": 26},
        {"equipe": "Burnley",          "joues": 28, "victoires": 5,  "nuls": 7,  "defaites": 16, "buts_pour": 25, "buts_contre": 55, "points": 22},
        {"equipe": "AFC Bournemouth",  "joues": 28, "victoires": 5,  "nuls": 5,  "defaites": 18, "buts_pour": 27, "buts_contre": 62, "points": 20},
    ],
    "la_liga": [
        {"equipe": "FC Barcelone",       "joues": 30, "victoires": 24, "nuls": 4,  "defaites": 2,  "buts_pour": 81, "buts_contre": 30, "points": 76},
        {"equipe": "Real Madrid",        "joues": 30, "victoires": 21, "nuls": 6,  "defaites": 3,  "buts_pour": 67, "buts_contre": 31, "points": 69},
        {"equipe": "Villarreal CF",      "joues": 30, "victoires": 17, "nuls": 7,  "defaites": 6,  "buts_pour": 60, "buts_contre": 40, "points": 58},
        {"equipe": "Atletico de Madrid", "joues": 30, "victoires": 17, "nuls": 6,  "defaites": 7,  "buts_pour": 53, "buts_contre": 32, "points": 57},
        {"equipe": "Real Betis",         "joues": 30, "victoires": 13, "nuls": 6,  "defaites": 11, "buts_pour": 46, "buts_contre": 39, "points": 45},
        {"equipe": "Real Sociedad",      "joues": 30, "victoires": 12, "nuls": 5,  "defaites": 13, "buts_pour": 40, "buts_contre": 39, "points": 41},
        {"equipe": "Celta de Vigo",      "joues": 30, "victoires": 12, "nuls": 5,  "defaites": 13, "buts_pour": 43, "buts_contre": 37, "points": 41},
        {"equipe": "Getafe CF",          "joues": 30, "victoires": 11, "nuls": 5,  "defaites": 14, "buts_pour": 30, "buts_contre": 36, "points": 38},
        {"equipe": "Espanyol",           "joues": 30, "victoires": 11, "nuls": 5,  "defaites": 14, "buts_pour": 37, "buts_contre": 45, "points": 38},
        {"equipe": "Athletic Club",      "joues": 30, "victoires": 11, "nuls": 5,  "defaites": 14, "buts_pour": 38, "buts_contre": 47, "points": 38},
        {"equipe": "Osasuna",            "joues": 30, "victoires": 11, "nuls": 4,  "defaites": 15, "buts_pour": 38, "buts_contre": 39, "points": 37},
        {"equipe": "Rayo Vallecano",     "joues": 30, "victoires": 10, "nuls": 5,  "defaites": 15, "buts_pour": 35, "buts_contre": 41, "points": 35},
        {"equipe": "Valencia CF",        "joues": 30, "victoires": 10, "nuls": 5,  "defaites": 15, "buts_pour": 38, "buts_contre": 48, "points": 35},
        {"equipe": "Girona FC",          "joues": 30, "victoires": 9,  "nuls": 7,  "defaites": 14, "buts_pour": 41, "buts_contre": 54, "points": 34},
        {"equipe": "Sevilla FC",         "joues": 30, "victoires": 9,  "nuls": 4,  "defaites": 17, "buts_pour": 33, "buts_contre": 46, "points": 31},
        {"equipe": "Alaves",             "joues": 30, "victoires": 9,  "nuls": 4,  "defaites": 17, "buts_pour": 32, "buts_contre": 43, "points": 31},
        {"equipe": "Mallorca",           "joues": 30, "victoires": 9,  "nuls": 4,  "defaites": 17, "buts_pour": 33, "buts_contre": 45, "points": 31},
        {"equipe": "Elche CF",           "joues": 30, "victoires": 8,  "nuls": 5,  "defaites": 17, "buts_pour": 28, "buts_contre": 46, "points": 29},
        {"equipe": "Levante UD",         "joues": 30, "victoires": 7,  "nuls": 5,  "defaites": 18, "buts_pour": 28, "buts_contre": 47, "points": 26},
        {"equipe": "Real Oviedo",        "joues": 30, "victoires": 5,  "nuls": 6,  "defaites": 19, "buts_pour": 26, "buts_contre": 54, "points": 21},
    ],
    "bundesliga": [
        {"equipe": "Bayern Munich",         "joues": 28, "victoires": 22, "nuls": 3,  "defaites": 3,  "buts_pour": 97, "buts_contre": 29, "points": 69},
        {"equipe": "Borussia Dortmund",     "joues": 28, "victoires": 16, "nuls": 5,  "defaites": 7,  "buts_pour": 60, "buts_contre": 42, "points": 53},
        {"equipe": "RB Leipzig",            "joues": 28, "victoires": 15, "nuls": 6,  "defaites": 7,  "buts_pour": 58, "buts_contre": 38, "points": 51},
        {"equipe": "VfB Stuttgart",         "joues": 28, "victoires": 14, "nuls": 6,  "defaites": 8,  "buts_pour": 55, "buts_contre": 44, "points": 48},
        {"equipe": "TSG Hoffenheim",        "joues": 28, "victoires": 13, "nuls": 6,  "defaites": 9,  "buts_pour": 50, "buts_contre": 41, "points": 45},
        {"equipe": "Bayer Leverkusen",      "joues": 28, "victoires": 12, "nuls": 7,  "defaites": 9,  "buts_pour": 52, "buts_contre": 43, "points": 43},
        {"equipe": "Eintracht Frankfurt",   "joues": 28, "victoires": 12, "nuls": 6,  "defaites": 10, "buts_pour": 53, "buts_contre": 47, "points": 42},
        {"equipe": "SC Freiburg",           "joues": 28, "victoires": 11, "nuls": 7,  "defaites": 10, "buts_pour": 41, "buts_contre": 38, "points": 40},
        {"equipe": "Hamburger SV",          "joues": 28, "victoires": 11, "nuls": 7,  "defaites": 10, "buts_pour": 43, "buts_contre": 44, "points": 40},
        {"equipe": "Werder Bremen",         "joues": 28, "victoires": 10, "nuls": 7,  "defaites": 11, "buts_pour": 42, "buts_contre": 45, "points": 37},
        {"equipe": "FC Augsburg",           "joues": 28, "victoires": 9,  "nuls": 8,  "defaites": 11, "buts_pour": 35, "buts_contre": 40, "points": 35},
        {"equipe": "1. FC Koln",            "joues": 28, "victoires": 9,  "nuls": 7,  "defaites": 12, "buts_pour": 38, "buts_contre": 46, "points": 34},
        {"equipe": "Bor. Monchengladbach",  "joues": 28, "victoires": 8,  "nuls": 6,  "defaites": 14, "buts_pour": 35, "buts_contre": 49, "points": 30},
        {"equipe": "FSV Mainz 05",          "joues": 28, "victoires": 8,  "nuls": 6,  "defaites": 14, "buts_pour": 34, "buts_contre": 48, "points": 30},
        {"equipe": "Union Berlin",          "joues": 28, "victoires": 8,  "nuls": 6,  "defaites": 14, "buts_pour": 30, "buts_contre": 44, "points": 30},
        {"equipe": "VfL Wolfsburg",         "joues": 28, "victoires": 7,  "nuls": 6,  "defaites": 15, "buts_pour": 33, "buts_contre": 49, "points": 27},
        {"equipe": "FC St. Pauli",          "joues": 28, "victoires": 6,  "nuls": 6,  "defaites": 16, "buts_pour": 26, "buts_contre": 55, "points": 24},
        {"equipe": "FC Heidenheim",         "joues": 28, "victoires": 6,  "nuls": 5,  "defaites": 17, "buts_pour": 28, "buts_contre": 58, "points": 23},
    ],
    "serie_a": [
        {"equipe": "Inter Milan",   "joues": 31, "victoires": 22, "nuls": 6,  "defaites": 3,  "buts_pour": 73, "buts_contre": 27, "points": 72},
        {"equipe": "Napoli",        "joues": 31, "victoires": 20, "nuls": 5,  "defaites": 6,  "buts_pour": 58, "buts_contre": 28, "points": 65},
        {"equipe": "AC Milan",      "joues": 31, "victoires": 19, "nuls": 6,  "defaites": 6,  "buts_pour": 61, "buts_contre": 35, "points": 63},
        {"equipe": "Atalanta BC",   "joues": 31, "victoires": 17, "nuls": 7,  "defaites": 7,  "buts_pour": 65, "buts_contre": 38, "points": 58},
        {"equipe": "Juventus FC",   "joues": 31, "victoires": 16, "nuls": 8,  "defaites": 7,  "buts_pour": 50, "buts_contre": 33, "points": 56},
        {"equipe": "Como 1907",     "joues": 31, "victoires": 15, "nuls": 7,  "defaites": 9,  "buts_pour": 53, "buts_contre": 40, "points": 52},
        {"equipe": "AS Roma",       "joues": 31, "victoires": 14, "nuls": 8,  "defaites": 9,  "buts_pour": 51, "buts_contre": 41, "points": 50},
        {"equipe": "Lazio",         "joues": 31, "victoires": 14, "nuls": 6,  "defaites": 11, "buts_pour": 46, "buts_contre": 38, "points": 48},
        {"equipe": "Fiorentina",    "joues": 31, "victoires": 12, "nuls": 8,  "defaites": 11, "buts_pour": 44, "buts_contre": 40, "points": 44},
        {"equipe": "Bologna FC",    "joues": 31, "victoires": 11, "nuls": 9,  "defaites": 11, "buts_pour": 42, "buts_contre": 43, "points": 42},
        {"equipe": "Torino FC",     "joues": 31, "victoires": 11, "nuls": 7,  "defaites": 13, "buts_pour": 37, "buts_contre": 38, "points": 40},
        {"equipe": "Udinese",       "joues": 31, "victoires": 10, "nuls": 8,  "defaites": 13, "buts_pour": 36, "buts_contre": 40, "points": 38},
        {"equipe": "Genoa CFC",     "joues": 31, "victoires": 9,  "nuls": 9,  "defaites": 13, "buts_pour": 34, "buts_contre": 42, "points": 36},
        {"equipe": "Parma Calcio",  "joues": 31, "victoires": 9,  "nuls": 7,  "defaites": 15, "buts_pour": 35, "buts_contre": 50, "points": 34},
        {"equipe": "Hellas Verona", "joues": 31, "victoires": 8,  "nuls": 7,  "defaites": 16, "buts_pour": 32, "buts_contre": 48, "points": 31},
        {"equipe": "Cagliari",      "joues": 31, "victoires": 7,  "nuls": 9,  "defaites": 15, "buts_pour": 29, "buts_contre": 46, "points": 30},
        {"equipe": "Lecce",         "joues": 31, "victoires": 6,  "nuls": 8,  "defaites": 17, "buts_pour": 26, "buts_contre": 52, "points": 26},
        {"equipe": "Empoli FC",     "joues": 31, "victoires": 5,  "nuls": 9,  "defaites": 17, "buts_pour": 25, "buts_contre": 51, "points": 24},
        {"equipe": "Pisa SC",       "joues": 31, "victoires": 5,  "nuls": 8,  "defaites": 18, "buts_pour": 23, "buts_contre": 54, "points": 23},
        {"equipe": "Cremonese",     "joues": 31, "victoires": 3,  "nuls": 7,  "defaites": 21, "buts_pour": 22, "buts_contre": 64, "points": 16},
    ],
}

# Top buteurs par championnat (saison 2025-26, avril 2026)
BUTEURS = {
    "ligue1": [
        {"nom": "M. Blas",       "club": "Lens",    "buts": 16},
        {"nom": "B. Barcola",    "club": "PSG",     "buts": 14},
        {"nom": "I. Sahraoui",   "club": "Lens",    "buts": 13},
        {"nom": "A. Lacazette",  "club": "OL",      "buts": 12},
        {"nom": "L. Orban",      "club": "OM",      "buts": 11},
    ],
    "premier_league": [
        {"nom": "E. Haaland",    "club": "Man City",    "buts": 22},
        {"nom": "M. Salah",      "club": "Liverpool",   "buts": 18},
        {"nom": "C. Palmer",     "club": "Chelsea",     "buts": 16},
        {"nom": "A. Isak",       "club": "Newcastle",   "buts": 16},
        {"nom": "B. Saka",       "club": "Arsenal",     "buts": 14},
    ],
    "la_liga": [
        {"nom": "R. Lewandowski","club": "Barcelone",   "buts": 22},
        {"nom": "K. Mbappe",     "club": "Real Madrid", "buts": 19},
        {"nom": "V. Junior",     "club": "Real Madrid", "buts": 15},
        {"nom": "A. Griezmann",  "club": "Atletico",    "buts": 14},
        {"nom": "A. Budimir",    "club": "Osasuna",     "buts": 13},
    ],
    "bundesliga": [
        {"nom": "H. Kane",       "club": "Bayern",      "buts": 25},
        {"nom": "S. Guirassy",   "club": "Dortmund",    "buts": 17},
        {"nom": "O. Marmoush",   "club": "Frankfurt",   "buts": 15},
        {"nom": "L. Openda",     "club": "Leipzig",     "buts": 14},
        {"nom": "F. Wirtz",      "club": "Leverkusen",  "buts": 13},
    ],
    "serie_a": [
        {"nom": "R. Lukaku",     "club": "Napoli",      "buts": 20},
        {"nom": "L. Martinez",   "club": "Inter",       "buts": 18},
        {"nom": "D. Vlahovic",   "club": "Juventus",    "buts": 15},
        {"nom": "R. Leao",       "club": "Milan",       "buts": 14},
        {"nom": "A. Lookman",    "club": "Atalanta",    "buts": 14},
    ],
}


def get_classement(championnat):
    # Essaie de recuperer le classement depuis l'API
    # Si ca ne marche pas, utilise les donnees de secours
    id_champ = IDS_CHAMPIONNATS.get(championnat)
    if not id_champ:
        return DONNEES_SECOURS.get(championnat, [])

    url = f"{URL_API}/competitions/{id_champ}/standings"
    headers = {"X-Auth-Token": CLE_API}

    try:
        reponse = requests.get(url, headers=headers, timeout=10)
        reponse.raise_for_status()
        data = reponse.json()

        # On cherche le classement general (type TOTAL)
        for table in data.get("standings", []):
            if table.get("type") == "TOTAL":
                classement = []
                for ligne in table["table"]:
                    classement.append({
                        "equipe":       ligne["team"]["name"],
                        "joues":        ligne["playedGames"],
                        "victoires":    ligne["won"],
                        "nuls":         ligne["draw"],
                        "defaites":     ligne["lost"],
                        "buts_pour":    ligne["goalsFor"],
                        "buts_contre":  ligne["goalsAgainst"],
                        "points":       ligne["points"],
                    })
                classement.sort(key=lambda x: (x["points"], x["buts_pour"] - x["buts_contre"]), reverse=True)
                return classement

    except Exception as e:
        print(f"API indisponible ({e}), donnees de secours utilisees.")

    return DONNEES_SECOURS.get(championnat, [])


def afficher_buteurs(championnat):
    # Affiche le top 5 des buteurs dans le terminal
    liste = BUTEURS.get(championnat, [])
    if not liste:
        print("Pas de donnees buteurs pour ce championnat.")
        return

    print(f"\nTop buteurs :")
    for i, joueur in enumerate(liste, 1):
        print(f"  {i}. {joueur['nom']} ({joueur['club']}) — {joueur['buts']} buts")
